# OpenHunt

A python library used to expedite data analysis via statistical functions and visualizations.

## Requirements

Python 3+

## Installation

You can install it via PIP:

```
pip install openhunt
```

Or you can also do the following:

```
git clone https://github.com/hunters-forge/openhunt
cd openhunt
pip install
```

# Author

* Jose Luis Rodriguez [@Cyb3rPandaH](https://twitter.com/Cyb3rPandaH)

# Contributors

* Roberto Rodriguez [@Cyb3rWard0g](https://twitter.com/Cyb3rWard0g)

