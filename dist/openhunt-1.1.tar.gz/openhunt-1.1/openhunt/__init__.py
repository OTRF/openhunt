#!/usr/bin/env python

from .logparser import winlogbeat